<?php
require_once 'db.php';
$id=$_GET['id'];
$faction_id=$_GET['faction_id'];

$sql="update cards set faction_id='{$faction_id}' where id = {$id}";
$stmt=$db->exec($sql);
if($stmt){
    echo "sikeres módosítás";
}
    else
 echo "nem sikerült :c";


?>