<?php
require_once 'db.php';
//$sql="SELECT * FROM `film` ORDER by id";
$sql="SELECT * FROM factions";

$stmt=$db->query($sql);
echo json_encode($stmt->fetchAll());

?>