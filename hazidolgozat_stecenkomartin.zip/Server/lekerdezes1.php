
<?php
$id = $_GET["ertek"];
require_once 'db.php';
//$sql="SELECT * FROM `film` ORDER by id";
$sql="SELECT rarity,name FROM `cards`INNER JOIN factions ON factions.faction_id = cards.faction_id WHERE factions.faction_id=".$id;

$stmt=$db->query($sql);
echo json_encode($stmt->fetchAll());

?>