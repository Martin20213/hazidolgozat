<?php
require_once "db.php";
$faction=$_GET['nev'];

$sql = "ALTER TABLE factions AUTO_INCREMENT = 1; INSERT INTO `factions`(`faction`) VALUES ('".$faction."')";

$stmt=$db->exec($sql);
echo $stmt;
?>