<?php
require_once 'db.php';
//$sql="SELECT * FROM `film` ORDER by id";
$sql="SELECT * FROM cards";

$stmt=$db->query($sql);
echo json_encode($stmt->fetchAll());

?>