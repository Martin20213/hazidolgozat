
<table class="table table-striped">
            <thead>
            <th>Id</th>
            <th>name</th>
            <th>rarity</th>
            <th>factionid</th>
            <th>&nbsp;</th>
        </thead>
        <tbody>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
        </tbody>
        </table>

        <script>
            function fetchy(){
                fetch('../server/read.php')
            .then(response=>response.json())
            .then(data=>szakrender(data))
            }
            fetchy();
    
            function szakrender(data){
                let tblStrszak=''
                for(let obj of data)
                tblStrszak+=`<tr><td>${obj.id}</td><td>${obj.name}</td><td>${obj.rarity}</td><td><input type="number" class="border border-danger" id="text${obj.id}" value=${obj.faction_id}> </td>
                <td class="btn btn-success" id="${obj.id}" onclick="update(this)">Módosít</td></tr>`;
                
                document.querySelector('tbody').innerHTML=tblStrszak    
            }

            function update(obj){
                console.log(obj.id);
                let id = obj.id;
                let faction_id = document.getElementById("text"+obj.id).value;
                console.log(faction_id);
                
                fetch(`../server/updateLeiras.php?id=${id}&faction_id=${faction_id}`)
                .then(response => response.text())
                .then(data=>{ window.alert("Sikeres módosítás!");
                fetchy();
                }
                );
                
            }

  
                
        </script>