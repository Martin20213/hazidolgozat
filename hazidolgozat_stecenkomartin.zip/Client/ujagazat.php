<form class="form-ininle">
    <input type="text" id="nev" class="form-control" placeholder="Írd be a faction nevét!" value="">
    <input type="button" class="btn btn-primary" onclick="uj()" value="mentés"> 

</form>

<script>

   function uj(){
        let neve=document.getElementById('nev').value
        console.log(neve);

       if(neve!=""){
        fetch("../server/insertagazat.php?nev="+neve)
        .then(response=>response.text())
        .then(data=>window.alert("Beszúrás sikeres!"));
        
    }

}

</script>