fetch(`../server/read2.php`)
  .then(response => response.json())
  .then(data => fuggveny3(data));


  function fuggveny3(data){

    
    let dataok="<option value=`0`>Válassz egy kártyát</option>"
  

    for(let obj of data){
        

      dataok+=`<option value="${obj.faction_id}">${obj.faction}</option>`
                
        
    }
    document.querySelector("select").innerHTML =dataok;

  }

function megjelenit(obj){

  fetch(`../server/lekerdezes1.php?ertek=`+obj.value)
 .then(response => response.json())
  .then(data =>  kiiras(data))



}
    

function kiiras(adat){

  document.getElementById("tr").innerHTML="";

  for(let obj of adat){


    
  document.getElementById("tr").innerHTML+=`<tr><td>${obj.name}</td><td>${obj.rarity}</td></tr>`;
  }
}