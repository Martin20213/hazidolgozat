 fetch(`../server/read.php`)
  .then(response => response.json())
  .then(data => fuggveny(data));

 
  

  function fuggveny(data){

    console.log(data)
    let dataok=""
  
    for(let obj of data){
        
       
        dataok+=`<tr><td>${obj.id}</td><td>${obj.name}</td><td>${obj.rarity}</td><td>${obj.faction_id}</td></tr>`
        
    }
    
    
    
    
    document.querySelector("tbody").innerHTML =dataok;
    
    
    console.log(data[0])
    
    let kulcsok = Object.keys(data[0])
    console.log(kulcsok);
    for(let kulcs of kulcsok){
        document.querySelector("tr").innerHTML +=`<th>${kulcs}</th>`
    }
    
    }


    
    
    
    