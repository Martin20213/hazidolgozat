
    fetch(`../server/read2.php`)
    .then(response => response.json())
    .then(data => fuggveny2(data));
   
    function fuggveny2(data){

        console.log(data)
        let dataok=""
      
        for(let obj of data){
            
           
            dataok+=`<tr><td>${obj.faction_id}</td><td>${obj.faction}</td></tr>`
            
        }
        
        
        
        
        document.querySelector("tbody").innerHTML =dataok;
        
        
        console.log(data[0])
        
        let kulcsok = Object.keys(data[0])
        console.log(kulcsok);
        for(let kulcs of kulcsok){
            document.querySelector("tr").innerHTML +=`<th>${kulcs}</th>`
        }
        
        }