<h1>Főoldal</h1>


<div class="jumbotron row">

    <div class="col-md-6">
        <img src="fileok/logo.png" class="img-fluid" alt="Nem jeleníthető meg">
    </div>

    <div class="col-md-6">
        <p>A Rush Royale-ban a tornyokat hatalmas harcosok és varázslók váltják fel! 
        A hősöknek a vár védelme a céljuk,ők az utolsó reménységek az ellenségekkel szemben. 
        Nézd meg őket vagy vedd kézbe az irányítást, irányítsd, ahogy esőnyilak és mágikus 
        rakéták vívják a harcot a horda védelmében!
        </p>

        <img src="fileok/game.jpg" class="img-fluid" alt="Nem jeleníthető meg">

    </div>

</div>