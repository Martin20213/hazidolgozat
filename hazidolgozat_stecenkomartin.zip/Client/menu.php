<!DOCTYPE html>
<html lang="en" class="bg-dark">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Menü</title>
</head>

<style type="text/css">

.table    { border:ridge 2px #ffaf69 ; background-color:#ffaf69; color:black; }
.table td { border:inset 3px #ffc107; }
</style>

<body class="bg-warning">
    <div class = "container-fluid">
        <nav class = "navbar navbar-expand-sm navbar-dark bg-dark">
        <ul class="navbar-nav">
        <li class="nav item"><a href="menu.php?program=fooldi.php" class="nav-link">RR Főoldal</a></li>
            <li class="nav item"><a href="menu.php" class="nav-link">Cards</a></li>
            <li class="nav item"><a href="menu.php?program=termek.php" class="nav-link">Factions</a></li>

            <li class="nav item"><a href="menu.php?program=beluliszakok.php" class="nav-link">Tulajdonságok</a></li>
            <li class="nav item"><a href="menu.php?program=torol.php" class="nav-link">Töröl</a></li>

            <li class="nav item"><a href="menu.php?program=ujagazat.php" class="nav-link">Új faction</a></li>

            <li class="nav item"><a href="menu.php?program=modosit.php" class="nav-link">Módosít</a></li>


        </ul>
        </nav> 
    </div>
    <div class="container "> 
         <?php
         if(isset($_GET["program"]))
            include $_GET["program"];
        else
            include "fooldal.php";

         ?>
         <table class="table table-bordered">
        <thead>
            <tr></tr>
        </thead>
            <tbody></tbody>
    </table>
    </div>
    <script src="valami.js"></script>
</body>
</html>