<h1>Kártya törlés</h1>
<table class="table table-stripped">
    <thead class="table table-dark">
        <th>Id</th>
        <th>Szám</th>
        <th>Szakma</th>
        <th>Ágazat</th>
        <th>&nbsp;</th>
    </thead>
    <tbody id="szakok"></tbody>
</table>


<script>

    function fetchy(){
    fetch("../server/read.php")
.then(response=>response.json())
.then(data=>render(data))

}

fetchy();




function render(data){
  
    let adatStr=""
    for(let obj of data){
        adatStr+=`<tr><td>${obj.id}</td><td>${obj.name}</td><td>${obj.rarity}</td><td>${obj.faction_id}</td>
                    <td class="btn btn-danger" id="${obj.id}" onclick="del(this)">delete</td></tr>`
    }
    document.getElementById("szakok").innerHTML=adatStr
}
    function del(obj){
        
        fetch(`../server/deleteszakmak.php?id=${obj.id}`)
        .then(response=>response.text())
        .then(data=>{

            if(data){
                window.alert("Sikeres törlés!");
                fetchy();
            }
        })

}
</script>