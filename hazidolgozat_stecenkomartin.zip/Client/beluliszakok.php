<h1>Tulajdonságok</h1>
 
<div class="jumbotron">    
           
<p><b>Kártyák:</b></p>

<style type="text/css">

table    { border:ridge 2px #ffaf69 ; background-color:#ffaf69; color:black; }
table td { border:inset 3px #ffc107; }

</style>


<center><select id="lista" onchange="megjelenit(this);">
        </select>
<div id="factions">
        <table>
                <tbody id="tr">
     
                </tbody>
        </table>
        
</div>
</div>
</center>

<script src="harmadik.js"></script>
